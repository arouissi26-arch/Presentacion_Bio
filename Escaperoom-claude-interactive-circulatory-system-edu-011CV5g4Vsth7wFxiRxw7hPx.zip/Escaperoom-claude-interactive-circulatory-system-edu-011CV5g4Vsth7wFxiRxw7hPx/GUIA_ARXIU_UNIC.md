# Guia: Presentació en Un Sol Arxiu

## Arxiu Principal

**presentacio-completa.html** - Arxiu únic amb tot el codi integrat

Aquest arxiu conté:
- Tot el CSS dins de `<style>`
- Tot el JavaScript dins de `<script>`
- Les 20 diapositives completes

## Com Utilitzar-lo

1. **Obre l'arxiu**: Simplement obre `presentacio-completa.html` amb el teu navegador
2. **Assegura't que les imatges estiguin a la mateixa carpeta**:
   - `imagen-sistema-sanguineo.jpg`
   - `imagen-cuerpo-masculino.jpg`

## Navegació

- **Clic amb el ratolí**: Avança a la següent diapositiva
- **Tecla →** o **Espai**: Següent diapositiva
- **Tecla ←**: Diapositiva anterior
- **Home**: Anar a la primera diapositiva
- **End**: Anar a l'última diapositiva
- **Esc**: Tornar a la pantalla de benvinguda

## Característiques

- ✅ 20 diapositives educatives
- ✅ Disseny elegant vermell i blau
- ✅ Animacions 3D experimentals
- ✅ Imatges reals integrades
- ✅ Tot en un sol arxiu HTML
- ✅ Responsive (s'adapta a diferents pantalles)

## Presentar

Per fer la presentació davant la classe:
1. Obre `presentacio-completa.html` al navegador
2. Posa el navegador en pantalla completa (F11)
3. Fes clic per començar
4. Avança amb clics o amb la tecla d'espai

## Notes

- Les imatges han d'estar a la mateixa carpeta que l'arxiu HTML
- No necessites connexió a internet (excepte per la font Montserrat)
- Si vols canviar alguna cosa, tot el codi està dins del mateix arxiu
