# Guia de Presentació - El Transport de Substàncies al Cos Humà

## 🎯 Objectiu
Aquesta guia us ajudarà a realitzar una presentació de **20 minuts** utilitzant l'aplicació web interactiva.

---

## 📋 Estructura de la Presentació (20 minuts)

### 1. Introducció (2 minuts)
**Responsable suggerit: 1 persona**

- Obrir l'aplicació i mostrar la pantalla de benvinguda
- Presentar el títol: "El Transport de Substàncies al Cos Humà"
- Presentar-vos tots els membres de l'equip
- Explicar breument què és el transport de substàncies:
  > "El nostre cos és com una ciutat molt ben organitzada que necessita carreteres per transportar aliments, aigua i retirar escombraries. Avui explorarem com el nostre organisme fa arribar nutrients i oxigen a totes les cèl·lules."

**Acció:** Clicar "Començar l'Exploració"

---

### 2. Nivell 1 - Pell i Transport Cel·lular (4 minuts)
**Responsable suggerit: Aissa o Ivan**

**Començar amb el nivell "Pell i epidermis"**

#### A) Mostrar la pell (1 min)
- Clicar sobre el cos humà
- Obrir panel: "Pell i Epidermis"
- Explicar:
  - La pell és la nostra primera barrera protectora
  - És l'òrgan més gran del cos (2 m²)
  - Es regenera cada 28 dies

#### B) Transport Cel·lular (3 min)
- Anar a la pestanya "Transport Cel·lular"
- Explicar els dos tipus principals:

**TRANSPORT PASSIU:**
> "Com deixar-se portar pel corrent d'un riu - no requereix energia"
- Difusió simple: O₂ i CO₂ passen directament
- Osmosi: L'aigua passa per aquaporines
- Difusió facilitada: Glucosa necessita proteïnes ajudants

**TRANSPORT ACTIU:**
> "Com nedar contra corrent - necessita energia (ATP)"
- Bomba Na⁺/K⁺: Expulsa 3 sodis i entra 2 potassis
- **Curiositat:** Les neurones utilitzen el 70% de la seva energia només per aquesta bomba!

#### C) Mostrar els botons de SANG i LIMFA (30 seg)
- Assenyalar les icones laterals
- Dir: "Aquests són els dos sistemes de transport principals que explorarem"

---

### 3. Nivell 2 - Vasos Sanguinis (4 minuts)
**Responsable suggerit: Roger o Unai**

**Canviar al nivell "Vasos sanguinis"**

#### A) Artèries (2 min)
- Clicar sobre els vasos vermells
- Explicar:
  - Transporten sang rica en O₂ des del cor
  - Parets gruixudes per suportar pressió alta
  - **Dada impressionant:** Tenim 100.000 km de vasos sanguinis!
- Pestanya "Funció en el Transport":
  - Distribueixen O₂, nutrients, hormones
  - La sang viatja a 5 km/h a les artèries grans

#### B) Venes (2 min)
- Clicar sobre els vasos blaus
- Explicar:
  - Retornen sang pobra en O₂ cap al cor
  - Parets més primes, pressió més baixa
  - Tenen vàlvules per evitar retrocés
- Pestanya "Mecanisme de Retorn":
  - Es mouen gràcies als músculs quan ens movem
  - **Consell de salut:** "Per això és important fer exercici!"

---

### 4. Nivell 3 - Cor i Òrgans (5 minuts)
**Responsable suggerit: Yeremi o Aissa**

**Canviar al nivell "Cor"**

#### A) El Cor (3 min)
- Clicar sobre el cor (animació de pulsació)
- Explicar l'anatomia bàsica:
  - 4 cambres: 2 aurícules + 2 ventricles
  - Funciona com una bomba doble

- Anar a "Aurícules i Ventricles":
  - Costat dret: sang pobra en O₂ → pulmons
  - Costat esquerre: sang rica en O₂ → tot el cos

- Anar a "El Batec Cardíac":
  - Explicar les 3 fases: Diàstole → Sístole auricular → Sístole ventricular
  - **Curiositat:** Batega 100.000 vegades al dia!

- Anar a "Doble Circulació":
  - Circulació pulmonar: Cor → Pulmons → Cor (guanya O₂)
  - Circulació sistèmica: Cor → Tot el cos → Cor (distribueix O₂)

#### B) Pulmons (2 min)
- Clicar sobre els pulmons
- Explicar l'intercanvi de gasos:
  - 600 milions d'alvèols
  - Superfície de 70 m² (una pista de tennis!)
  - Per difusió: O₂ entra, CO₂ surt

---

### 5. La Sang - El Vehicle de Transport (3 minuts)
**Responsable suggerit: Ivan o Roger**

**Tornar al nivell "Pell i epidermis" i clicar la icona "SANG"**

#### A) Composició (1 min)
- Mostrar la pestanya "Què és la Sang?"
- Explicar:
  - 55% plasma (líquid)
  - 44% glòbuls vermells
  - 1% glòbuls blancs i plaquetes

#### B) Glòbuls Vermells (1 min)
- Transporten O₂ gràcies a l'hemoglobina
- Viuen 120 dies
- **Dada impressionant:** El cos produeix 2,4 milions per segon!

#### C) Glòbuls Blancs i Plaquetes (1 min)
- Glòbuls blancs: Soldats del sistema immunitari
- Plaquetes: Coagulació (tanquen ferides)
- **Curiositat:** Una gota de sang té 5 milions de glòbuls vermells

---

### 6. Sistema Limfàtic - La Xarxa Paral·lela (3 minuts)
**Responsable suggerit: Unai o Yeremi**

**Clicar la icona "LIMFA"**

#### A) Què és el Sistema Limfàtic? (1 min)
- Líquid transparent (limfa)
- Paral·lel al sistema circulatori
- NO té cor - es mou amb els músculs

#### B) Funcions Principals (1.5 min)
- **Retornar líquid:** Cada dia 3L de plasma surten dels capil·lars
- **Transportar greixos:** Els greixos de l'intestí viatgen primer per la limfa
- **Defensa:** Ganglis limfàtics filtren microorganismes

#### C) Ganglis Limfàtics (30 seg)
- Estacions de control de seguretat
- Quan estàs malalt, s'inflamen (coll, aixelles)
- Produeixen anticossos

---

### 7. Òrgans Principals (3 minuts - opcional segons temps)
**Responsable suggerit: Qualsevol**

**Canviar al nivell "Òrgans principals"**

Fer un recorregut ràpid mostrant:

- **Fetge:** Fàbrica química del cos (500 funcions!)
- **Intestins:** Absorbeixen nutrients
  - Superfície d'absorció: 300 m²!
- **Ronyons:** Filtren 180 litres de sang al dia

---

### 8. Conclusió i Consells de Salut (2 minuts)
**Responsable suggerit: Tots junts**

#### Resum final:
> "Hem vist com el cos té dos sistemes de transport que treballen 24/7:
> - Sistema circulatori: Ràpid, amb cor, distribueix O₂
> - Sistema limfàtic: Lent, sense cor, defensa i neteja
> - Tot controlat a nivell cel·lular amb transport passiu i actiu"

#### Consells de salut:
- 🥗 **Alimentació equilibrada:** Fruites, verdures, proteïnes
- 💧 **Hidratació:** 1,5-2 litres d'aigua al dia
- 🏃 **Exercici regular:** Millora la circulació sanguínia i limfàtica
- 😴 **Descans adequat:** 8-9 hores de son
- 🚭 **No fumar:** Danya els vasos sanguinis

#### Curiositats finals (impactar a l'audiència):
- ✨ El cor batega 3.000 milions de vegades en 80 anys
- ✨ La sang completa un circuit en menys d'1 minut
- ✨ Sense sistema limfàtic, moriríem en 24 hores
- ✨ Produïm 2,4 milions de glòbuls vermells cada segon

**Tancar amb:** "Gràcies per l'atenció! Teniu alguna pregunta?"

---

## 🎨 Consells per a una Bona Presentació

### Abans de la presentació:
- [ ] Proveu l'aplicació diverses vegades
- [ ] Assegureu-vos que la connexió a internet funciona
- [ ] Obriu l'aplicació en mode pantalla completa (F11)
- [ ] Repartiu-vos les seccions segons les vostres fortaleses
- [ ] Practiceu les transicions entre seccions

### Durant la presentació:
- 👆 **Interacció:** Animeu a fer preguntes
- 🎯 **Claredat:** Parleu a un ritme moderat
- 👀 **Visual:** Assenyaleu els elements clau a la pantalla
- 📊 **Dades:** Utilitzeu les curiositats per mantenir l'atenció
- 💬 **Connexió:** Relacioneu amb experiències quotidianes (quan et fas mal, quan tens febre...)

### Control del temps:
- ⏰ Porteu un rellotge o cronòmetre
- Si aneu massa ràpid: Afegiu més curiositats
- Si aneu massa lent: Salteu els òrgans opcionals

---

## 📱 Ordre de Clicks Recomanat

1. ▶️ "Començar l'Exploració"
2. 🧑 Nivell "Pell i epidermis"
3. 👆 Clic sobre el cos → "Pell" → Pestanya "Transport Cel·lular"
4. 🩸 Clic sobre "SANG" → Explorar pestanyes
5. 💧 Tancar panel (✕)
6. 🩸 Nivell "Vasos sanguinis"
7. 👆 Clic artèries → Explorar
8. 👆 Clic venes → Explorar
9. ❤️ Nivell "Cor"
10. 👆 Clic cor → Explorar pestanyes
11. 👆 Clic pulmons
12. 🧑 Tornar a nivell "Pell"
13. 💧 Clic "LIMFA" → Explorar pestanyes
14. 🫁 (Opcional) Nivell "Òrgans principals" → Recorregut ràpid
15. 🎉 Conclusió i preguntes

---

## ❓ Possibles Preguntes de l'Audiència

**P: Per què el cor té dues bombes?**
R: Una per enviar sang als pulmons (baixa pressió) i una altra per enviar-la a tot el cos (alta pressió).

**P: Què passa si tenim pocs glòbuls vermells?**
R: Es produeix anèmia - cansament perquè les cèl·lules no reben prou oxigen.

**P: Per què els ganglis s'inflamen quan estem malalts?**
R: Perquè estan produint molts més limfòcits per combatre la infecció.

**P: Podem viure amb un sol ronyó?**
R: Sí! Un ronyó pot fer el treball de dos. Moltes persones donen un ronyó.

**P: Quanta sang tenim?**
R: Homes: 5,7 L / Dones: 4,3 L / Nens: 70-75 ml/kg

---

## 🌟 Èxits amb la Presentació!

Recordeu: L'objectiu és que l'audiència entengui com funciona el transport de substàncies al cos de manera **visual, interactiva i memorable**.

**Consell final:** Gaudiu de la presentació! Si vosaltres esteu entusiasmats, l'audiència també ho estarà. 🚀

---

**Preparada per:** El vostre equip educatiu
**Data:** 2025
