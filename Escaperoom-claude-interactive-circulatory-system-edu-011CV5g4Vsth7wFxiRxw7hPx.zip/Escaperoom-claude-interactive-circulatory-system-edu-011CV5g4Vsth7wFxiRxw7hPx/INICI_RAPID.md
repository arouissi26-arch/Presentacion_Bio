# 🚀 Inici Ràpid

## Obrir l'Aplicació - 3 Opcions

### Opció 1: Doble Clic (Més Fàcil)
1. Localitza el fitxer `index.html` a la carpeta del projecte
2. Fes doble clic sobre `index.html`
3. S'obrirà automàticament amb el teu navegador predeterminat
4. ✅ **Fet!** L'aplicació està llesta per usar

### Opció 2: Arrossegar al Navegador
1. Obre el teu navegador (Chrome, Firefox, Safari, Edge)
2. Arrossega el fitxer `index.html` a la finestra del navegador
3. ✅ **Fet!**

### Opció 3: Servidor Local (Recomanat per a presentacions)
```bash
# Si tens Python instal·lat:
python3 -m http.server 8000

# O amb Python 2:
python -m SimpleHTTPServer 8000

# Després obre al navegador:
http://localhost:8000
```

**Avantatge:** URL neta i professional per compartir

---

## ⚙️ Configuració Recomanada per a la Presentació

### Abans de començar:
1. **Tanca altres pestanyes del navegador** (per evitar distraccions)
2. **Activa el mode pantalla completa**: Prem `F11` (Windows/Linux) o `Cmd+Ctrl+F` (Mac)
3. **Desactiva notificacions**: Mode "No molestar" al sistema operatiu
4. **Comprova la connexió a internet**: L'aplicació necessita CDN per funcionar
5. **Augmenta el zoom si és necessari**: `Ctrl/Cmd + "+"` per fer tot més gran

### Durant la presentació:
- 🖱️ **Navegació suau**: Moviments lents amb el ratolí
- 👆 **Clics precisos**: Apunta bé als elements interactius
- ⏸️ **Pauses**: Deixa temps per llegir el text abans de canviar
- 💬 **Explica mentre cliques**: No deixis silencis

---

## 🎯 Test Ràpid - Comprova que tot funciona

### Checklist abans de la presentació:

- [ ] L'aplicació s'obre correctament
- [ ] Es veu la pantalla de benvinguda
- [ ] El botó "Començar l'Exploració" funciona
- [ ] La barra lateral esquerra canvia els nivells
- [ ] Es pot clicar sobre els elements del cos
- [ ] El panel lateral dret s'obre i es tanca
- [ ] Les pestanyes del panel funcionen
- [ ] Les animacions són fluides (no van lentes)
- [ ] El text és llegible a la distància de projecció

---

## 🖥️ Consells per a Projecció

### Si projecteu amb projector/pantalla gran:

1. **Resolució:** Configura la resolució a 1920x1080 (Full HD)
2. **Contrast:** Augmenta el contrast del projector si el text es veu poc
3. **Distància:** Col·loca el projector prou lluny perquè es vegi tot
4. **Lluminositat:** Baixa les llums de la sala per millor visibilitat
5. **Colors:** Comprova que els colors es veuen bé (vermell de sang, blau de venes)

### Posició de l'ordinador:
- Deixa l'ordinador en un lloc on puguis veure la pantalla mentre parles
- Utilitza un ratolí (més precís que el touchpad)
- Tingues aigua a prop 💧

---

## 📊 Contingut Disponible per Explorar

### Nivell 0 - Pell i Epidermis
- **Pell:** Transport cel·lular, funcions, curiositats
- **SANG (icona):** Composició, glòbuls vermells/blancs, plaquetes, plasma
- **LIMFA (icona):** Components, funcions, ganglis limfàtics, comparació

### Nivell 1 - Vasos Sanguinis
- **Artèries:** Estructura, funció en el transport, dades
- **Venes:** Característiques, mecanisme de retorn, curiositats

### Nivell 2 - Òrgans Principals
- **Estómac:** Digestió, funcions
- **Fetge:** Metabolisme, desintoxicació, funcions
- **Intestins:** Absorció de nutrients, intestí prim i gros
- **Ronyons:** Filtratge, funcions, dades

### Nivell 3 - Cor
- **Cor:** Aurícules, ventricles, vàlvules, batec, circulació
- **Pulmons:** Intercanvi de gasos, estructura, curiositats

**Total de pestanyes:** Més de 50 pestanyes diferents amb informació! 🎓

---

## ⏱️ Temps Estimat per Secció

| Secció | Temps Mínim | Temps Recomanat |
|--------|-------------|-----------------|
| Introducció | 1 min | 2 min |
| Transport Cel·lular | 2 min | 4 min |
| Vasos Sanguinis | 2 min | 4 min |
| Cor i Pulmons | 3 min | 5 min |
| La Sang | 2 min | 3 min |
| Sistema Limfàtic | 2 min | 3 min |
| Òrgans | 1 min | 3 min |
| Conclusió | 1 min | 2 min |
| **TOTAL** | **14 min** | **26 min** |

💡 **Consell:** Ajusteu el temps segons l'interès de l'audiència

---

## 🆘 Solució de Problemes

### L'aplicació no s'obre:
- ✅ Comprova que tens connexió a internet (necessària per CDN)
- ✅ Prova amb un navegador diferent
- ✅ Desactiva extensions del navegador (ad-blockers, etc.)

### Les animacions van lentes:
- ✅ Tanca altres programes i pestanyes
- ✅ Actualitza el navegador a l'última versió
- ✅ Prova amb Chrome (millor rendiment)

### El text és massa petit:
- ✅ Prem `Ctrl/Cmd + "+"` per fer zoom
- ✅ Canvia la resolució de pantalla

### El panel no s'obre:
- ✅ Assegura't de clicar directament sobre l'element (no al costat)
- ✅ Espera que les animacions acabin abans de clicar

### Colors estranys al projector:
- ✅ Ajusta la configuració de color del projector
- ✅ Calibra la temperatura de color

---

## 📱 Compatibilitat de Navegadors

### ✅ Navegadors recomanats:
- **Google Chrome** (versió 90+) - **MILLOR OPCIÓ**
- **Mozilla Firefox** (versió 88+)
- **Microsoft Edge** (versió 90+)
- **Safari** (versió 14+) - Mac

### ❌ No recomanats:
- Internet Explorer (obsolet)
- Navegadors molt antics

---

## 🎓 Material de Suport Addicional

A més de l'aplicació, teniu:

1. **README.md:** Documentació completa del projecte
2. **GUIA_PRESENTACIO.md:** Guia detallada per a l'exposició
3. **index.html:** L'aplicació (aquest fitxer)

**Consell:** Imprimiu o tingueu oberta la `GUIA_PRESENTACIO.md` en una altra pantalla per consultar durant l'exposició.

---

## 📞 Últims Consells

### Dia de la presentació:
- 🔋 **Bateria carregada** (o porta el carregador)
- 💾 **Còpia de seguretat:** Porta l'aplicació en un USB
- 📱 **Telèfon en silenci**
- 🗣️ **Veu clara i forta**
- 😊 **Somriure i confiança**

### Recordeu:
> "Una bona preparació és la clau d'una gran presentació!"

---

## ✨ Funcionalitats Destacades

- 🎨 **Animacions fluides** amb Framer Motion
- 🖱️ **Interactivitat total** - Cada element és clicable
- 📚 **Més de 50 pestanyes** d'informació educativa
- 🔄 **4 nivells de profunditat** per explorar
- 💡 **Curiositats fascinants** que capturen l'atenció
- 🎯 **Basat en documentació científica** real
- 🌈 **Disseny atractiu** amb colors educatius

---

## 🚀 Esteu Preparats!

Amb aquesta aplicació i les guies proporcionades, teniu tot el necessari per fer una **presentació excel·lent** que impressionarà a la vostra audiència.

**Molta sort! 🍀**

---

**Equip:**
- Aissa Rousi
- Ivan Rios
- Roger Omegna
- Unai Jimenez
- Yeremi Suarez

💪 **Endavant!**
