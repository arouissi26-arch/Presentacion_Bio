# 🎯 Guia d'Ús - Presentació Simplificada

## ✨ Nou Disseny Minimalista

La presentació ara té un disseny **completament simplificat** per màxima claredat i elegància.

---

## 🖱️ Com Utilitzar-la

### És MUY SENZILL:

1. **Obre `presentacio.html`**
2. **Fes clic A QUALSEVOL LLOC de la pantalla**
3. **Això és tot!** ✨

---

## 🎮 Controls

### Amb el Ratolí:
- **Clic a QUALSEVOL LLOC** → Passa a la següent diapositiva

### Amb el Teclat:
- **Espai** → Següent diapositiva
- **Fletxa Dreta →** → Següent
- **Fletxa Esquerra ←** → Anterior
- **Home** → Primera diapositiva
- **End** → Última diapositiva

---

## 🎨 Disseny

### Característiques:
- ✅ **Fons fosc fix** (#1a1a2e) - Sense moviment
- ✅ **Text blanc** sobre fons fosc - Màxima llegibilitat
- ✅ **Sense caixes visibles** - Tot transparent
- ✅ **Sense barres** - Ni scroll ni progrés
- ✅ **Sense botons** - Interfície neta
- ✅ **Un sol clic** - Experiència fluida

### Estil:
Similar a **Prezi, Keynote o presentacions professionals** - Minimalista i elegant

---

## 📖 Flux de la Presentació

1. **Pantalla inicial:**
   - Títol del projecte
   - Noms dels estudiants
   - Text: "Fes clic per començar ▶"

2. **15 Diapositives:**
   - Cada clic avança una diapositiva
   - Animacions suaus
   - Text blanc ben visible

3. **Final:**
   - Després de l'última diapositiva
   - Torna automàticament al principi
   - Pots començar de nou

---

## 🎬 Per a la Presentació en Classe

### Abans:
```bash
# 1. Obre l'arxiu
open presentacio.html

# 2. Pantalla completa
Prem F11 (Windows/Linux)
Prem Cmd+Ctrl+F (Mac)

# 3. Prova que funciona
Fes uns quants clics per provar
```

### Durant:
- Parla mentre mostres cada diapositiva
- Fes clic quan vulguis avançar
- **NO hi ha pressa** - controla tu el ritme
- Si et passes, prem ← per tornar enrere

### Consells:
- 💡 Projecta en pantalla gran
- 🗣️ Explica amb calma (1-2 min per slide)
- ⏸️ Fes pauses per preguntes
- 🎯 Total: 20-25 minuts perfectes

---

## ⚡ Avantatges del Nou Disseny

### Per a l'Exposició:
- ✨ **Elegància professional**
- 👆 **Simplicitat total** (un clic)
- 🎨 **Sense distraccions** visuals
- 👀 **Text sempre llegible**
- 🖥️ **Perfecte per projectors**

### Per al Presentador:
- 🧘 **Menys elements a gestionar**
- 🎯 **Focus al contingut**
- ⚡ **Navegació instantània**
- 🔄 **Loop automàtic al final**
- ✅ **Impossible perdre's**

---

## 🆚 Comparació

| Element | Versió Anterior | Nova Versió |
|---------|----------------|-------------|
| Fons | Gradient animat | Color fix fosc |
| Botons | Visibles a baix | Ocults |
| Navegació | Botons o teclat | **Un clic** |
| Caixes | Blanques grans | Transparents |
| Scroll | Amb barra | Sense |
| Comptador | Visible | Ocult |
| Barra progrés | Visible | Oculta |
| Estil | Colorit | **Minimalista** |

---

## 💻 Requisits

### Navegadors Compatibles:
- ✅ **Chrome** (recomanat)
- ✅ Firefox
- ✅ Safari
- ✅ Edge
- ✅ Qualsevol navegador modern

### NO necessites:
- ❌ Internet (tot és local)
- ❌ Instal·lar res
- ❌ Configurar res

---

## 🎓 Per als Estudiants

### Ordre de Presentació (20-25 min):

**Inici (2 min):**
- Diapositiva 1: Introducció

**Cos (18 min):**
- Diapositives 2-14: Contingut principal
- 1-2 minuts per diapositiva

**Final (2 min):**
- Diapositiva 15: Conclusió i preguntes

### Repartiment Suggerit:
- **Aissa:** Diapositives 1-3 (Intro, transport cel·lular, sang)
- **Ivan:** Diapositives 4-6 (Cor, vàlvules, circulació)
- **Roger:** Diapositives 7-9 (Vasos, limfàtic, ganglis)
- **Unai:** Diapositives 10-12 (Comparació, òrgans, ronyons)
- **Yeremi:** Diapositives 13-15 (Curiositats, salut, conclusió)

---

## 🔧 Solució de Problemes

### No puc clicar:
- ✅ Espera que la pàgina carregui del tot
- ✅ Prova amb la tecla Espai

### El text no es veu:
- ✅ Augmenta la lluminositat de la pantalla
- ✅ Apaga els llums de la sala
- ✅ Fes zoom amb Ctrl/Cmd + "+"

### Va massa ràpid:
- ✅ Controla tu els clics - pren el teu temps
- ✅ Si et passes, prem Fletxa Esquerra

### Vull tornar a començar:
- ✅ Prem Home per anar a l'inici
- ✅ O F5 per recarregar la pàgina

---

## 🌟 Característiques Tècniques

### Animacions CSS:
- Fade in/out entre diapositives
- Aparició progressiva d'elements
- Transicions suaus (0.5-0.6s)

### Colors:
- **Fons:** #1a1a2e (blau fosc)
- **Text principal:** #ffffff (blanc)
- **Text secundari:** #e0e0e0 (gris clar)
- **Accents:** #a0a0ff (lila)

### Performance:
- Càrrega instantània
- 0 lag
- Fluid a 60 FPS

---

## 📱 Responsive

Optimitzat per:
- 🖥️ **PC/Portàtil** (Full HD, 4K)
- 📺 **Projectors** (1080p, 720p)
- 📱 **Tablets** (iPad, Android)

---

## 🎯 Recordatori Final

### LA CLAU:
> **Un clic = Una diapositiva**
>
> Així de simple! 🚀

### CONSELL:
> Practica 2-3 vegades abans de l'exposició
>
> Així et sentiràs segur i natural 💪

---

## 📞 Dubtes?

1. Obre `presentacio.html`
2. Fes clic per veure com funciona
3. Practica uns minuts
4. **Ja estàs preparat!** ✅

---

**Molta sort amb la presentació! 🍀**

---

**Equip:**
- Aissa Rousi
- Ivan Rios
- Roger Omegna
- Unai Jimenez
- Yeremi Suarez

**© 2025 - Projecte Educatiu de Biologia**
