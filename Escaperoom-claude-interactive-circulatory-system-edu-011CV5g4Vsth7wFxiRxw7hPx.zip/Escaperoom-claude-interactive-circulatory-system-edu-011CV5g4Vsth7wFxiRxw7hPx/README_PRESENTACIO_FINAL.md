# Presentació: El Transport de Substàncies al Cos Humà

## 📊 Informació de la Presentació

- **Arxiu principal:** `presentacio-final.html`
- **Diapositives totals:** 38
- **Nivell educatiu:** 3r ESO
- **Idioma:** Català
- **Format:** HTML amb tot el codi integrat (un sol arxiu)

## 🎨 Característiques

### Colors (10 variants diferents!)
- ❤️ Vermell fosc (#8B0000)
- 💙 Blau fosc (#1e1e3f)
- 💚 Verd fosc (#0a4d2e)
- 💜 Morat (#4a0080)
- 🧡 Taronja (#cc4400)
- 🩵 Cian (#006b7d)
- 💛 Groc (#b8860b)
- 🩵 Teal (#00695c)
- 💗 Magenta (#880e4f)
- 💙 Indi (#1a237e)

### Imatges (5 imatges reals)
1. `imagen-membrana-celular.jpg` - Transport cel·lular
2. `imagen-corazon-anatomia.jpg` - Anatomia del cor
3. `imagen-corazon-detall.jpg` - Detall del cor
4. `imagen-sistema-sanguineo.jpg` - Sistema de vasos sanguinis
5. `imagen-cuerpo-masculino.jpg` - Cos humà saludable

## 📚 Contingut de les Diapositives

### Bloc 1: Transport Cel·lular (Diapos 1-9)
1. Portada
2. Per què és important el transport?
3. Transport a nivell cel·lular - Membrana plasmàtica
4. Transport passiu
5. Difusió simple
6. Osmosi
7. Difusió facilitada
8. Transport actiu
9. Bomba sodi-potassi (Na⁺/K⁺)

### Bloc 2: Sistema Circulatori (Diapos 10-24)
10. Aparell circulatori - Introducció
11. El cor - Anatomia
12. Fases del batec cardíac (Part 1)
13. Intercanvi de gasos als pulmons
14. Fases del batec cardíac (Part 2)
15. Els dos circuits (pulmonar i sistèmic)
16. Els vasos sanguinis
17. Artèries
18. Venes
19. Capil·lars
20. La sang - Components
21. Plasma sanguini
22. Glòbuls vermells (eritròcits)
23. Glòbuls blancs (leucòcits)
24. Plaquetes (trombòcits)

### Bloc 3: Sistema Limfàtic (Diapos 25-29)
25. Sistema limfàtic - Introducció
26. Components del sistema limfàtic
27. Funcions del sistema limfàtic
28. Ganglis limfàtics i infeccions
29. Comparació circulatori vs limfàtic (amb taula!)

### Bloc 4: Nutrients i Metabolisme (Diapos 30-31)
30. Transport de nutrients específics
31. Metabolisme cel·lular (anabolisme i catabolisme)

### Bloc 5: Salut i Conclusions (Diapos 32-38)
32. Cuida els teus sistemes de transport
33. Evita hàbits nocius
34. Curiositats fascinants
35. Més dades increïbles
36. Conclusió
37. Recordatori final
38. Gràcies

## 🎮 Com Utilitzar-la

### Obrir la presentació
1. Obre l'arxiu `presentacio-final.html` amb qualsevol navegador modern
2. Les imatges han d'estar a la mateixa carpeta que l'HTML

### Controls de navegació
- **Clic** o **Espai**: Avançar a la següent diapositiva
- **Fletxa esquerra**: Tornar a la diapositiva anterior
- **Fletxa dreta** o **Espai**: Avançar
- **Home**: Anar a la primera diapositiva
- **End**: Anar a l'última diapositiva
- **Esc**: Tornar a la pantalla de benvinguda

### Mode presentació
Per presentar a classe:
1. Obre l'arxiu amb el navegador
2. Prem **F11** per posar pantalla completa
3. Fes clic per començar
4. Avança amb clics o amb la tecla d'espai

## ✅ Temes Coberts (Programa 3r ESO)

### Transport Cel·lular ✓
- Membrana plasmàtica
- Transport passiu (difusió simple, osmosi, difusió facilitada)
- Transport actiu (bomba Na⁺/K⁺)

### Sistema Circulatori ✓
- Anatomia del cor (4 cambres, vàlvules)
- Circulació pulmonar i sistèmica
- Vasos sanguinis (artèries, venes, capil·lars)
- Composició de la sang
- Fases del batec cardíac (sístole, diàstole)

### Sistema Limfàtic ✓
- Components (vasos, ganglis, òrgans limfàtics)
- Funcions (retorn de líquid, transport de greixos, defensa)
- Diferències amb el sistema circulatori

### Metabolisme i Salut ✓
- Anabolisme i catabolisme
- Transport de nutrients
- Hàbits saludables
- Curiositats científiques

## 👥 Autors
- Aissa Rousi
- Ivan Rios
- Roger Omegna
- Unai Jimenez
- Yeremi Suarez

## 🎯 Durada estimada
Aproximadament **25-30 minuts** de presentació (depenent del ritme i les explicacions)

---

**Nota:** Totes les imatges han d'estar a la mateixa carpeta que `presentacio-final.html` perquè es vegin correctament.
