// Presentation Logic
// Presentation Logic
let slides = [];
let currentSlide = 0;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    generateSlides(); // Generate slides from data
    initCustomCursor();
    initParallax();
    initTiltCards();
    updateSlideClasses();

    // Keyboard Navigation
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowRight' || e.key === ' ') nextSlide();
        if (e.key === 'ArrowLeft') prevSlide();
    });
});

function generateSlides() {
    const container = document.querySelector('.presentation-container');
    if (!container || typeof slidesData === 'undefined') return;

    container.innerHTML = ''; // Clear existing

    slidesData.forEach((slideData, index) => {
        const slide = document.createElement('div');
        slide.className = 'slide';
        if (index === 0) slide.classList.add('active');
        slide.innerHTML = slideData.content;

        // Add tilt effect class to cards if they exist
        const cards = slide.querySelectorAll('.highlight-box, .data-item, .column');
        cards.forEach(card => card.classList.add('tilt-card'));

        container.appendChild(slide);
    });

    // Update slides variable after generation
    slides = document.querySelectorAll('.slide');
}

// Navigation
function nextSlide() {
    if (currentSlide < slides.length - 1) {
        currentSlide++;
        updateSlideClasses();
    }
}

function prevSlide() {
    if (currentSlide > 0) {
        currentSlide--;
        updateSlideClasses();
    }
}

function updateSlideClasses() {
    slides.forEach((slide, index) => {
        slide.classList.remove('active');
        if (index === currentSlide) {
            slide.classList.add('active');
            // Reset animations for the active slide
            const animatedElements = slide.querySelectorAll('.animate-in-up');
            animatedElements.forEach(el => {
                el.style.animation = 'none';
                el.offsetHeight; /* trigger reflow */
                el.style.animation = null;
            });
        }
    });
}

// Custom Cursor
function initCustomCursor() {
    const dot = document.createElement('div');
    const outline = document.createElement('div');
    dot.className = 'cursor-dot';
    outline.className = 'cursor-outline';
    document.body.appendChild(dot);
    document.body.appendChild(outline);

    window.addEventListener('mousemove', (e) => {
        const posX = e.clientX;
        const posY = e.clientY;

        dot.style.left = `${posX}px`;
        dot.style.top = `${posY}px`;

        outline.animate({
            left: `${posX}px`,
            top: `${posY}px`
        }, { duration: 500, fill: "forwards" });
    });
}

// Parallax Effect
function initParallax() {
    document.addEventListener('mousemove', (e) => {
        const x = (window.innerWidth - e.pageX * 2) / 100;
        const y = (window.innerHeight - e.pageY * 2) / 100;

        const bg = document.querySelector('.slide.active .slide-bg');
        if (bg) {
            bg.style.transform = `translateX(${x}px) translateY(${y}px) scale(1.1)`;
        }
    });
}

// 3D Tilt Effect for Cards
function initTiltCards() {
    document.addEventListener('mousemove', (e) => {
        const cards = document.querySelectorAll('.slide.active .tilt-card');

        cards.forEach(card => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            const centerX = rect.width / 2;
            const centerY = rect.height / 2;

            const rotateX = ((y - centerY) / centerY) * -10; // Max rotation deg
            const rotateY = ((x - centerX) / centerX) * 10;

            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
        });
    });

    // Reset on mouse leave
    document.addEventListener('mouseout', (e) => {
        const cards = document.querySelectorAll('.tilt-card');
        cards.forEach(card => {
            card.style.transform = `perspective(1000px) rotateX(0) rotateY(0)`;
        });
    });
}

// Multiplayer Quiz Launcher
window.startMultiplayerQuiz = function (event) {
    if (event) event.stopPropagation();

    const overlay = document.createElement('div');
    overlay.id = 'quiz-overlay';
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.zIndex = '2000';
    overlay.style.background = '#000';
    overlay.style.display = 'flex';
    overlay.style.flexDirection = 'column';
    overlay.className = 'animate__animated animate__fadeIn';

    const closeBtn = document.createElement('button');
    closeBtn.innerHTML = '✕ TANCAR';
    closeBtn.style.position = 'absolute';
    closeBtn.style.top = '20px';
    closeBtn.style.right = '20px';
    closeBtn.style.zIndex = '2001';
    closeBtn.style.padding = '10px 20px';
    closeBtn.style.background = '#ff4d4d';
    closeBtn.style.color = 'white';
    closeBtn.style.border = 'none';
    closeBtn.style.borderRadius = '5px';
    closeBtn.style.cursor = 'pointer';
    closeBtn.onclick = () => {
        overlay.remove();
    };

    const iframe = document.createElement('iframe');
    iframe.src = 'quiz-multiplayer/host.html';
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    iframe.style.border = 'none';

    overlay.appendChild(closeBtn);
    overlay.appendChild(iframe);
    document.body.appendChild(overlay);
};

// Interactive Diagram Logic
window.showInfo = function (el, title, text) {
    const panel = document.getElementById('info-panel');
    if (panel) {
        panel.innerHTML = '<h3>' + title + '</h3><p>' + text + '</p>';
        panel.style.borderColor = '#FFD700';
        panel.style.transform = 'scale(1.05)';
        setTimeout(() => panel.style.transform = 'scale(1)', 200);
    }
};

// Drag and Drop Logic (Blood Sorter)
window.allowDrop = function (ev) {
    ev.preventDefault();
};

window.drag = function (ev) {
    ev.dataTransfer.setData("text", ev.target.id);
};

window.drop = function (ev) {
    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
    var draggedElement = document.getElementById(data);

    // Check if drop target is correct category
    if (ev.target.classList.contains('drop-zone')) {
        const targetType = ev.target.getAttribute('data-type');
        const itemType = draggedElement.getAttribute('data-type');

        if (targetType === itemType) {
            ev.target.appendChild(draggedElement);
            draggedElement.style.cursor = 'default';
            draggedElement.draggable = false;
            draggedElement.classList.add('correct-drop');
            ev.target.classList.add('success-pulse');
            setTimeout(() => ev.target.classList.remove('success-pulse'), 500);
        } else {
            // Shake effect for wrong drop
            draggedElement.classList.add('shake');
            setTimeout(() => draggedElement.classList.remove('shake'), 500);
        }
    }
};
