// ULTIMATE MECHANICS ENGINE (The "200" Implementation)

const MechanicsEngine = {
    state: {
        xp: 0,
        level: 1,
        achievements: [],
        settings: {
            darkMode: true,
            sound: false,
            particles: true,
            voice: false
        }
    },

    init() {
        console.log("Mechanics Engine Initialized");
        this.setupSuperMenu();
        this.setupGamification();
        this.setupGlobalInteractions();
        this.applyRandomEntranceAnimations();
    },

    // --- 1. ENTRANCE ANIMATIONS (1-25) ---
    applyRandomEntranceAnimations() {
        const animations = [
            'mech-enter-blur', 'mech-enter-slide-bounce', 'mech-enter-zoom-explode',
            'mech-enter-rotate-y', 'mech-enter-pixel'
        ];

        // Hook into slide change
        const originalUpdate = window.updateSlideClasses;
        window.updateSlideClasses = function () {
            originalUpdate(); // Call original

            const activeSlide = slides[currentSlide];
            const elements = activeSlide.querySelectorAll('h1, p, img, .highlight-box');

            elements.forEach((el, index) => {
                // Randomly assign an animation class
                const randomAnim = animations[Math.floor(Math.random() * animations.length)];
                el.classList.add(randomAnim);
                el.style.animationDelay = `${index * 0.1}s`;
            });

            MechanicsEngine.addXP(10); // Gamification hook
        };
    },

    // --- 3. GLOBAL INTERACTIONS (51-80) ---
    setupGlobalInteractions() {
        document.addEventListener('click', (e) => {
            this.createRipple(e);
            this.addXP(1);
        });

        // Hover effects
        const interactables = document.querySelectorAll('button, a, .highlight-box');
        interactables.forEach(el => {
            el.classList.add('mech-hover-neon');
            el.addEventListener('mouseenter', () => this.playSound('hover'));
        });
    },

    createRipple(e) {
        const ripple = document.createElement('div');
        ripple.className = 'ripple';
        ripple.style.left = `${e.clientX}px`;
        ripple.style.top = `${e.clientY}px`;
        document.body.appendChild(ripple);
        setTimeout(() => ripple.remove(), 600);
    },

    // --- 4. SUPER MENU (81-110, 186-200) ---
    setupSuperMenu() {
        const overlay = document.createElement('div');
        overlay.className = 'super-menu-overlay';
        overlay.innerHTML = `
            <div class="super-menu-content">
                <div class="menu-section">
                    <h3>Personalization</h3>
                    <div class="menu-item"><span>Dark Mode</span> <div class="menu-toggle active" onclick="MechanicsEngine.toggleSetting('darkMode', this)"></div></div>
                    <div class="menu-item"><span>Sound Effects</span> <div class="menu-toggle" onclick="MechanicsEngine.toggleSetting('sound', this)"></div></div>
                    <div class="menu-item"><span>Voice Narration</span> <div class="menu-toggle" onclick="MechanicsEngine.toggleSetting('voice', this)"></div></div>
                </div>
                <div class="menu-section">
                    <h3>Navigation</h3>
                    <div class="menu-item" onclick="MechanicsEngine.jumpToSection('intro')"><span>Jump to Intro</span> ➜</div>
                    <div class="menu-item" onclick="MechanicsEngine.jumpToSection('cellular')"><span>Jump to Cellular</span> ➜</div>
                    <div class="menu-item" onclick="MechanicsEngine.jumpToSection('heart')"><span>Jump to Heart</span> ➜</div>
                </div>
                <div class="menu-section">
                    <h3>Gamification</h3>
                    <div class="menu-item"><span>Level</span> <span id="mech-level">1</span></div>
                    <div class="menu-item"><span>XP</span> <span id="mech-xp">0</span></div>
                </div>
                <button class="nav-btn" onclick="toggleSuperMenu()" style="margin-top: 20px;">Close</button>
            </div>
        `;
        document.body.appendChild(overlay);
        this.menuOverlay = overlay;
    },

    toggleSetting(setting, element) {
        this.state.settings[setting] = !this.state.settings[setting];
        element.classList.toggle('active');
        this.showAchievement('Tinkerer', 'Changed a setting');
    },

    jumpToSection(section) {
        // Simple mapping logic
        let target = 0;
        if (section === 'cellular') target = 2;
        if (section === 'heart') target = 10;
        currentSlide = target;
        updateSlideClasses();
        toggleSuperMenu();
    },

    // --- 5. GAMIFICATION (141-165) ---
    setupGamification() {
        const xpBar = document.createElement('div');
        xpBar.className = 'xp-overlay';
        xpBar.innerHTML = `<span>LVL <span id="hud-level">1</span></span> | <span>XP <span id="hud-xp">0</span></span>`;
        document.body.appendChild(xpBar);
    },

    addXP(amount) {
        this.state.xp += amount;
        document.getElementById('hud-xp').innerText = this.state.xp;
        document.getElementById('mech-xp').innerText = this.state.xp;

        if (this.state.xp > this.state.level * 100) {
            this.state.level++;
            document.getElementById('hud-level').innerText = this.state.level;
            document.getElementById('mech-level').innerText = this.state.level;
            this.showAchievement('Level Up!', `Reached Level ${this.state.level}`);
        }
    },

    showAchievement(title, desc) {
        const popup = document.createElement('div');
        popup.className = 'achievement-popup';
        popup.innerHTML = `<div class="achievement-icon">🏆</div><div><div>${title}</div><div style="font-size:0.8em; font-weight:normal;">${desc}</div></div>`;
        document.body.appendChild(popup);

        setTimeout(() => popup.classList.add('show'), 100);
        setTimeout(() => {
            popup.classList.remove('show');
            setTimeout(() => popup.remove(), 500);
        }, 3000);
    },

    playSound(type) {
        if (!this.state.settings.sound) return;
        // Placeholder for audio logic
    }
};

// Global Toggle Function
function toggleSuperMenu() {
    const overlay = document.querySelector('.super-menu-overlay');
    overlay.classList.toggle('active');
}

// Auto-init
document.addEventListener('DOMContentLoaded', () => {
    MechanicsEngine.init();
});
