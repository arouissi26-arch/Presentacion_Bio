const slidesData = [    // Diapositiva 1: Portada
    {
        content: `
            <div class="slide-bg bg-red-blue"></div>
            <div class="slide-content">
                <h1 class="slide-title">El Transport de Substàncies</h1>
                <p class="slide-subtitle">Al Cos Humà</p>
                <div class="highlight-box" style="max-width: 700px;">
                    <p style="font-size: 1.4rem; color: #ffffff;">Una exploració completa del sistema circulatori, limfàtic i transport cel·lular</p>
                </div>
                <div style="margin-top: 40px; font-size: 1.3rem; color: #d0d0d0;">
                    <p>Aissa Rousi • Ivan Rios • Roger Omegna</p>
                    <p style="margin-top: 10px;">Unai Jimenez • Yeremi Suarez</p>
                    <p style="margin-top: 20px; font-size: 1.1rem; color: #999;">3r ESO</p>
                </div>
            </div>
        `
    },

    // Diapositiva 2: Per què és important el transport?
    {
        content: `
            <div class="slide-bg bg-city"></div>
            <div class="slide-content">
                <h1 class="slide-title">Per què és important el transport?</h1>
                <p class="slide-subtitle">El cos humà com una ciutat ben organitzada</p>
                <div class="two-columns">
                    <div class="column">
                        <h3>Una ciutat necessita:</h3>
                        <p>Carreteres per transportar aliments</p>
                        <p style="margin-top: 15px;">Sistemes d'aigua potable</p>
                        <p style="margin-top: 15px;">Recollida d'escombraries</p>
                    </div>
                    <div class="column">
                        <h3>El nostre cos necessita:</h3>
                        <p>Transportar nutrients i oxigen</p>
                        <p style="margin-top: 15px;">Portar aigua a totes les cèl·lules</p>
                        <p style="margin-top: 15px;">Retirar productes de rebuig</p>
                    </div>
                </div>
                <div class="highlight-box" style="margin-top: 40px;">
                    <h4>Sense aquest transport constant...</h4>
                    <p>Les cèl·lules no podrien sobreviure! Avui explorarem els mecanismes fascinants que fan possible aquest transport vital.</p>
                </div>
            </div>
        `
    },

    // Diapositiva 3: Transport a nivell cel·lular
    {
        content: `
            <div class="slide-bg bg-cellular"></div>
            <div class="slide-content">
                <h1 class="slide-title">Transport a Nivell Cel·lular</h1>
                <p class="slide-subtitle">La membrana plasmàtica: la porta d'entrada</p>
                <div class="two-columns image-text">
                    <div class="column">
                        <img src="imagen-membrana-celular.jpg" alt="Membrana cel·lular" class="slide-image">
                    </div>
                    <div class="column">
                        <p style="font-size: 1.4rem; line-height: 1.8;">Totes les cèl·lules estan envoltades per una <strong>membrana plasmàtica</strong> que actua com una porta selectiva.</p>
                        <p style="margin-top: 25px; font-size: 1.4rem; line-height: 1.8;">Aquesta membrana decideix <strong>què pot entrar i sortir</strong> de la cèl·lula.</p>
                        <p style="margin-top: 25px; font-size: 1.4rem; line-height: 1.8; color: #FFD700;">És essencial per mantenir l'equilibri intern!</p>
                    </div>
                </div>
            </div>
        `
    },

    // Diapositiva 4: Transport passiu
    {
        content: `
            <div class="slide-bg bg-cellular"></div>
            <div class="slide-content">
                <h1 class="slide-title">Transport Passiu</h1>
                <p class="slide-subtitle">Sense despesa d'energia</p>
                <div class="highlight-box">
                    <h4>Com funciona?</h4>
                    <p>El transport passiu és com deixar-se portar pel corrent d'un riu: les substàncies es mouen de zones on hi ha més concentració cap a zones on n'hi ha menys, <strong>sense que la cèl·lula hagi de gastar energia</strong>.</p>
                </div>
                <ul class="elegant-list" style="margin-top: 40px;">
                    <li><strong>Difusió simple:</strong> Molècules petites (O₂, CO₂) travessen directament la membrana</li>
                    <li><strong>Osmosi:</strong> L'aigua es mou a través de proteïnes especials (aquaporines)</li>
                    <li><strong>Difusió facilitada:</strong> Molècules grans (glucosa) necessiten proteïnes transportadores</li>
                </ul>
            </div>
        `
    },

    // Diapositiva 5: Difusió simple
    {
        content: `
            <div class="slide-bg bg-cellular"></div>
            <div class="big-number">O₂</div>
            <div class="slide-content">
                <h1 class="slide-title">Difusió Simple</h1>
                <p class="slide-subtitle">El moviment natural de molècules petites</p>
                <div class="two-columns">
                    <div class="column">
                        <h3>Què és?</h3>
                        <p>Les molècules petites travessen directament la membrana cel·lular, movent-se d'on hi ha més concentració a on n'hi ha menys.</p>
                    </div>
                    <div class="column">
                        <h3>Exemple pràctic</h3>
                        <p>Quan respirem, l'<strong>oxigen (O₂)</strong> entra als pulmons i passa a la sang per difusió simple.</p>
                        <p style="margin-top: 20px;">Per què? Perquè hi ha més concentració d'O₂ als pulmons que a la sang!</p>
                    </div>
                </div>
                <div class="highlight-box" style="margin-top: 40px;">
                    <p style="font-size: 1.3rem;">També funciona amb el <strong>CO₂</strong> en direcció contrària: de la sang als pulmons per ser exhalat.</p>
                </div>
            </div>
        `
    },

    // Diapositiva 6: Osmosi
    {
        content: `
            <div class="slide-bg bg-water"></div>
            <div class="big-number">H₂O</div>
            <div class="slide-content">
                <h1 class="slide-title">Osmosi</h1>
                <p class="slide-subtitle">El transport específic de l'aigua</p>
                <ul class="elegant-list">
                    <li>L'aigua es mou a través de proteïnes especials anomenades <strong>aquaporines</strong></li>
                    <li>Va de zones amb menys soluts (més aigua) a zones amb més soluts (menys aigua)</li>
                    <li>És essencial per mantenir l'equilibri hídric de les cèl·lules</li>
                    <li>L'aigua representa aproximadament el <strong>60% del nostre pes corporal</strong></li>
                </ul>
                <div class="highlight-box" style="margin-top: 40px;">
                    <h4>Per què és important?</h4>
                    <p>Sense osmosi, les cèl·lules no podrien regular el seu contingut d'aigua i es desinflarien o explotarien!</p>
                </div>
            </div>
        `
    },

    // Diapositiva 7: Difusió facilitada
    {
        content: `
            <div class="slide-bg bg-cellular"></div>
            <div class="slide-content">
                <h1 class="slide-title">Difusió Facilitada</h1>
                <p class="slide-subtitle">Amb ajuda de proteïnes transportadores</p>
                <div class="two-columns">
                    <div class="column">
                        <h3>Com funciona?</h3>
                        <p>Molècules més grans com la <strong>glucosa</strong> no poden travessar directament la membrana.</p>
                        <p style="margin-top: 20px;">Necessiten l'ajuda de <strong>proteïnes transportadores</strong> que actuen com portes especials.</p>
                    </div>
                    <div class="column">
                        <h3>Exemple: La glucosa</h3>
                        <p>La glucosa és massa gran per passar sola.</p>
                        <p style="margin-top: 20px;">Proteïnes especials (GLUT) obren un canal perquè pugui entrar a la cèl·lula.</p>
                        <p style="margin-top: 20px; color: #FFD700;"><strong>Encara és transport passiu!</strong> No gasta energia.</p>
                    </div>
                </div>
            </div>
        `
    },

    // Diapositiva 8: Transport actiu
    {
        content: `
            <div class="slide-bg bg-cellular"></div>
            <div class="big-number">ATP</div>
            <div class="slide-content">
                <h1 class="slide-title">Transport Actiu</h1>
                <p class="slide-subtitle">Amb despesa d'energia (ATP)</p>
                <div class="highlight-box">
                    <h4>Contra corrent!</h4>
                    <p>Quan les substàncies necessiten moure's <strong>contra corrent</strong> (de zones de baixa concentració a zones d'alta concentració), la cèl·lula ha de gastar energia en forma d'<strong>ATP</strong>.</p>
                </div>
                <ul class="elegant-list" style="margin-top: 40px;">
                    <li>Utilitza energia de l'ATP (adenosina trifosfat)</li>
                    <li>Permet acumular substàncies dins o fora de la cèl·lula</li>
                    <li>És essencial per mantenir concentracions diferents a cada costat de la membrana</li>
                    <li>L'exemple més important és la <strong>bomba de sodi-potassi</strong></li>
                </ul>
            </div>
        `
    },

    // Diapositiva 9: Bomba Na+/K+
    {
        content: `
            <div class="slide-bg bg-electric"></div>
            <div class="slide-content">
                <h1 class="slide-title glitch-text" data-text="La Bomba Sodi-Potassi">La Bomba Sodi-Potassi</h1>
                <p class="slide-subtitle">Na⁺/K⁺ - El motor de les cèl·lules</p>
                <div class="two-columns">
                    <div class="column">
                        <h3>Com funciona?</h3>
                        <p>Expulsa <strong>3 ions de sodi (Na⁺)</strong> fora de la cèl·lula</p>
                        <p style="margin-top: 20px;">Introdueix <strong>2 ions de potassi (K⁺)</strong> a l'interior</p>
                        <p style="margin-top: 20px;">Utilitza <strong>1 molècula d'ATP</strong> per fer aquest treball</p>
                    </div>
                    <div class="column">
                        <h3>Per a què serveix?</h3>
                        <p>La transmissió dels <strong>impulsos nerviosos</strong></p>
                        <p style="margin-top: 20px;">La <strong>contracció muscular</strong></p>
                        <p style="margin-top: 20px;">Mantenir l'<strong>equilibri de la cèl·lula</strong></p>
                    </div>
                </div>
                <div class="highlight-box" style="margin-top: 30px;">
                    <h4>Curiositat increïble!</h4>
                    <p>Les neurones utilitzen gairebé el <strong>70% de la seva energia</strong> només per mantenir funcionant aquesta bomba!</p>
                </div>
            </div>
        `
    },

    // Diapositiva 10: Sistema circulatori - introducció
    {
        content: `
            <div class="slide-bg bg-heart"></div>
            <div class="slide-content">
                <h1 class="slide-title">L'Aparell Circulatori</h1>
                <p class="slide-subtitle">La xarxa de transport del cos</p>
                <div class="highlight-box">
                    <h4>Què és?</h4>
                    <p style="font-size: 1.3rem;">L'aparell circulatori és un <strong>circuit de vasos sanguinis ramificats</strong> per on circula la sang, impulsada pel bombament del cor.</p>
                </div>
                <div class="two-columns" style="margin-top: 40px;">
                    <div class="column">
                        <h3>Funcions principals:</h3>
                        <p>Distribuir nutrients a totes les cèl·lules</p>
                        <p style="margin-top: 15px;">Transportar oxigen des dels pulmons</p>
                        <p style="margin-top: 15px;">Retirar productes de rebuig</p>
                        <p style="margin-top: 15px;">Transportar hormones i cèl·lules de defensa</p>
                    </div>
                    <div class="column">
                        <h3>Components:</h3>
                        <p><strong>El cor:</strong> La bomba</p>
                        <p style="margin-top: 15px;"><strong>Vasos sanguinis:</strong> Les carreteres</p>
                        <p style="margin-top: 15px;"><strong>La sang:</strong> El vehicle de transport</p>
                    </div>
                </div>
            </div>
        `
    },

    // Diapositiva 11: El cor - anatomia (INTERACTIVA)
    {
        content: `
            <div class="slide-bg bg-heart"></div>
            <div class="slide-content">
                <h1 class="slide-title">El Cor: Anatomia Interactiva</h1>
                <p class="slide-subtitle">Fes clic als punts per explorar</p>
                <div class="two-columns image-text">
                    <div class="column interactive-diagram">
                        <img src="imagen-corazon-anatomia.jpg" alt="Anatomia del cor" class="slide-image">
                        
                        <!-- Hotspots -->
                        <div class="diagram-hotspot" style="top: 30%; left: 30%;" onclick="showInfo(this, 'Aurícula Dreta', 'Rep la sang desoxigenada del cos.')"></div>
                        <div class="hotspot-info">
                            <h4>Aurícula Dreta</h4>
                            <p>Rep la sang desoxigenada del cos.</p>
                        </div>

                        <div class="diagram-hotspot" style="top: 30%; right: 30%;" onclick="showInfo(this, 'Aurícula Esquerra', 'Rep la sang oxigenada dels pulmons.')"></div>
                        <div class="hotspot-info">
                            <h4>Aurícula Esquerra</h4>
                            <p>Rep la sang oxigenada dels pulmons.</p>
                        </div>

                        <div class="diagram-hotspot" style="bottom: 30%; left: 40%;" onclick="showInfo(this, 'Ventricle Dret', 'Bombeja sang als pulmons.')"></div>
                        <div class="hotspot-info">
                            <h4>Ventricle Dret</h4>
                            <p>Bombeja sang als pulmons.</p>
                        </div>

                        <div class="diagram-hotspot" style="bottom: 30%; right: 25%;" onclick="showInfo(this, 'Ventricle Esquerre', 'Bombeja sang a tot el cos. És la cambra més forta.')"></div>
                        <div class="hotspot-info">
                            <h4>Ventricle Esquerre</h4>
                            <p>Bombeja sang a tot el cos. És la cambra més forta.</p>
                        </div>
                    </div>
                    <div class="column">
                        <div id="info-panel" class="highlight-box" style="min-height: 200px; transition: all 0.3s;">
                            <h3>Explora el cor!</h3>
                            <p>Passa el ratolí o fes clic sobre els punts brillants de la imatge per descobrir la funció de cada part.</p>
                        </div>
                        <div style="margin-top: 30px;">
                            <p>Batega més de <strong>100.000 vegades al dia</strong></p>
                            <p style="margin-top: 15px;">Bombeja <strong>7.000 litres de sang</strong> cada dia</p>
                        </div>
                    </div>
                </div>
            </div>
        `
    },

    // Diapositiva 12: Fases del batec 1
    {
        content: `
            <div class="slide-bg bg-heart"></div>
            <div class="slide-content">
                <h1 class="slide-title">Fases del Batec Cardíac (1)</h1>
                <p class="slide-subtitle">Costat dret del cor - Circulació pulmonar</p>
                <ul class="elegant-list">
                    <li><strong>Pas 1:</strong> La sang pobra en O₂ i rica en CO₂ arriba al costat dret del cor per les venes caves</li>
                    <li><strong>Pas 2:</strong> La musculatura del cor està relaxada (diàstole)</li>
                    <li><strong>Pas 3:</strong> L'aurícula es contrau, augmentant la pressió sanguínia al ventricle</li>
                    <li><strong>Pas 4:</strong> Quan el ventricle es contrau (sístole), la vàlvula tricúspide es tanca</li>
                    <li><strong>Pas 5:</strong> La sang és impulsada a pressió a través de la vàlvula pulmonar</li>
                    <li><strong>Pas 6:</strong> La sang circula des de l'artèria pulmonar fins als capil·lars pulmonars</li>
                </ul>
            </div>
        `
    },

    // Diapositiva 13: Intercanvi de Gasos
    {
        content: `
            <div class="slide-bg bg-gas"></div>
            <div class="big-number">O₂</div>
            <div class="slide-content">
                <h1 class="slide-title">Intercanvi de Gasos</h1>
                <p class="slide-subtitle">Als capil·lars pulmonars</p>
                <div class="highlight-box">
                    <h4>Què passa als pulmons?</h4>
                    <p style="font-size: 1.4rem;">Als capil·lars pulmonars es produeix l'<strong>intercanvi de gasos:</strong></p>
                </div>
                <div class="data-grid" style="grid-template-columns: 1fr 1fr; margin-top: 50px;">
                    <div class="data-item">
                        <h5>La sang PERD</h5>
                        <p style="font-size: 1.4rem; margin-top: 15px;">CO₂ (diòxid de carboni)</p>
                        <p style="margin-top: 10px;">S'exhala fora del cos</p>
                    </div>
                    <div class="data-item">
                        <h5>La sang GUANYA</h5>
                        <p style="font-size: 1.4rem; margin-top: 15px;">O₂ (oxigen)</p>
                        <p style="margin-top: 10px;">Per portar a tot el cos</p>
                    </div>
                </div>
            </div>
        `
    },

    // Diapositiva 14: Fases del batec 2
    {
        content: `
            <div class="slide-bg bg-heart"></div>
            <div class="slide-content">
                <h1 class="slide-title">Fases del Batec Cardíac (2)</h1>
                <p class="slide-subtitle">Costat esquerre del cor - Circulació general</p>
                <ul class="elegant-list">
                    <li><strong>Pas 1:</strong> La sang rica en O₂ i pobra en CO₂ arriba al costat esquerre per les venes pulmonars</li>
                    <li><strong>Pas 2:</strong> La musculatura del cor està relaxada (diàstole)</li>
                    <li><strong>Pas 3:</strong> L'aurícula es contrau, augmentant la pressió sanguínia al ventricle</li>
                    <li><strong>Pas 4:</strong> Quan el ventricle es contrau (sístole), la vàlvula mitral es tanca</li>
                    <li><strong>Pas 5:</strong> La sang és impulsada a pressió a través de la vàlvula aòrtica</li>
                    <li><strong>Pas 6:</strong> La sang circula des de l'aorta fins als capil·lars de tot l'organisme</li>
                </ul>
            </div>
        `
    },

    // Diapositiva 15: Els dos circuits
    {
        content: `
            <div class="slide-bg bg-heart"></div>
            <div class="slide-content">
                <h1 class="slide-title">Els Dos Circuits</h1>
                <p class="slide-subtitle">Circulació pulmonar i circulació general</p>
                <div class="two-columns">
                    <div class="column">
                        <h3 style="color: #1e3a8a;">Circulació Pulmonar</h3>
                        <p>Del cor als pulmons i tornada</p>
                        <p style="margin-top: 15px;">La sang viatja del <strong>ventricle dret</strong> als pulmons</p>
                        <p style="margin-top: 15px;">Als pulmons <strong>recull O₂</strong> i allibera CO₂</p>
                        <p style="margin-top: 15px;">Torna al cor per l'<strong>aurícula esquerra</strong></p>
                    </div>
                    <div class="column">
                        <h3 style="color: #DC143C;">Circulació General</h3>
                        <p>Del cor a tot el cos i tornada</p>
                        <p style="margin-top: 15px;">La sang viatja del <strong>ventricle esquerre</strong> a tot el cos</p>
                        <p style="margin-top: 15px;">Reparteix <strong>O₂ i nutrients</strong> a les cèl·lules</p>
                        <p style="margin-top: 15px;">Torna al cor per l'<strong>aurícula dreta</strong></p>
                    </div>
                </div>
                <div class="highlight-box" style="margin-top: 30px;">
                    <p style="font-size: 1.2rem;"><strong>Important:</strong> Els dos circuits es produeixen al mateix temps! El so doble de cada batec és degut al tancament simultani de les vàlvules.</p>
                </div>
            </div>
        `
    },

    // Diapositiva 16: Vasos sanguinis
    {
        content: `
            <div class="slide-bg bg-blood"></div>
            <div class="slide-content">
                <h1 class="slide-title">Els Vasos Sanguinis</h1>
                <p class="slide-subtitle">Les carreteres del cos</p>
                <div class="two-columns image-text">
                    <div class="column">
                        <img src="imagen-sistema-sanguineo.jpg" alt="Sistema de vasos sanguinis" class="slide-image">
                    </div>
                    <div class="column">
                        <h3>Tres tipus principals:</h3>
                        <p style="margin-top: 20px;"><strong style="color: #DC143C;">Artèries:</strong> Porten sang del cor als teixits (parets gruixudes)</p>
                        <p style="margin-top: 20px;"><strong style="color: #1e3a8a;">Venes:</strong> Retornen sang dels teixits al cor (parets més primes)</p>
                        <p style="margin-top: 20px;"><strong style="color: #FFD700;">Capil·lars:</strong> Vasos microscòpics on es produeix l'intercanvi</p>
                    </div>
                </div>
                <div class="highlight-box" style="margin-top: 30px;">
                    <p style="font-size: 1.2rem;">Si posessim tots els vasos sanguinis en línia, farien <strong>97.000 quilòmetres</strong>! Gairebé 2,5 vegades la volta al món!</p>
                </div>
            </div>
        `
    },

    // Diapositiva 17: Artèries
    {
        content: `
            <div class="slide-bg bg-heart"></div>
            <div class="slide-content">
                <h1 class="slide-title">Artèries</h1>
                <p class="slide-subtitle">Les carreteres d'alta pressió</p>
                <div class="two-columns">
                    <div class="column">
                        <h3>Característiques</h3>
                        <p>Parets <strong>gruixudes i elàstiques</strong> que aguanten alta pressió</p>
                        <p style="margin-top: 15px;">Transporten sang <strong>oxigenada</strong> del cor als teixits</p>
                        <p style="margin-top: 15px;">Tenen capes de <strong>múscul llis</strong> que es contrauen</p>
                        <p style="margin-top: 15px;">Color <strong>vermell brillant</strong> (rica en O₂)</p>
                    </div>
                    <div class="column">
                        <h3>Artèries principals</h3>
                        <p><strong>Aorta:</strong> La més gran, surt del ventricle esquerre</p>
                        <p style="margin-top: 15px;"><strong>Caròtides:</strong> Porten sang al cervell</p>
                        <p style="margin-top: 15px;"><strong>Artèries pulmonars:</strong> Excepció! Porten sang desoxigenada als pulmons</p>
                    </div>
                </div>
            </div>
        `
    },

    // Diapositiva 18: Venes
    {
        content: `
            <div class="slide-bg bg-heart"></div>
            <div class="slide-content">
                <h1 class="slide-title">Venes</h1>
                <p class="slide-subtitle">El sistema de retorn</p>
                <ul class="elegant-list">
                    <li>Parets <strong>més primes</strong> que les artèries</li>
                    <li>Contenen <strong>vàlvules</strong> que impedeixen el reflux de sang</li>
                    <li>Transporten sang <strong>desoxigenada</strong> dels teixits al cor</li>
                    <li>La pressió sanguínia és molt més <strong>baixa</strong></li>
                    <li>Els <strong>músculs</strong> ajuden a empènyer la sang cap amunt</li>
                    <li>Color <strong>vermell fosc</strong> o blavós (pobra en O₂)</li>
                </ul>
                <div class="highlight-box" style="margin-top: 30px;">
                    <h4>Venes pulmonars: l'altra excepció!</h4>
                    <p>Les venes pulmonars són l'única excepció: porten sang <strong>oxigenada</strong> des dels pulmons al cor.</p>
                </div>
            </div>
        `
    },

    // Diapositiva 19: Capil·lars
    {
        content: `
            <div class="slide-bg bg-cellular"></div>
            <div class="spotlight-overlay"></div>
            <div class="slide-content">
                <h1 class="slide-title">Capil·lars: Exploració</h1>
                <p class="slide-subtitle">Mou el ratolí per il·luminar la foscor</p>
                <div class="highlight-box">
                    <h4>La xarxa més fina</h4>
                    <p>Els capil·lars són tan prims que els glòbuls vermells han de passar <strong>en fila índia</strong>. Només tenen una cèl·lula de gruix, cosa que permet l'intercanvi eficient de nutrients, oxigen i productes de rebuig entre la sang i els teixits.</p>
                </div>
                <div class="data-grid" style="margin-top: 40px;">
                    <div class="data-item">
                        <h5>Gruix</h5>
                        <p>1 cèl·lula</p>
                    </div>
                    <div class="data-item">
                        <h5>Quantitat</h5>
                        <p>Milers de milions</p>
                    </div>
                    <div class="data-item">
                        <h5>Superfície</h5>
                        <p>600 m²</p>
                    </div>
                </div>
            </div>
        `
    },

    // Diapositiva 20: La Sang - Joc de Classificació (INTERACTIVA)
    {
        content: `
            <div class="slide-bg bg-heart"></div>
            <div class="slide-content">
                <h1 class="slide-title">Joc: Components de la Sang</h1>
                <p class="slide-subtitle">Arrossega cada component a la seva funció!</p>
                
                <div class="layout-split" style="align-items: flex-start;">
                    <!-- Draggable Items -->
                    <div class="drag-container" style="display: flex; flex-wrap: wrap; gap: 20px; justify-content: center;">
                        <div id="rbc" class="draggable-item" draggable="true" ondragstart="drag(event)" data-type="oxygen" style="background: #ff4d4d; padding: 15px; border-radius: 10px; cursor: grab;">
                            🩸 Glòbuls Vermells
                        </div>
                        <div id="wbc" class="draggable-item" draggable="true" ondragstart="drag(event)" data-type="defense" style="background: #e0e0e0; color: #333; padding: 15px; border-radius: 10px; cursor: grab;">
                            🛡️ Glòbuls Blancs
                        </div>
                        <div id="platelet" class="draggable-item" draggable="true" ondragstart="drag(event)" data-type="clot" style="background: #ffd700; color: #333; padding: 15px; border-radius: 10px; cursor: grab;">
                            🩹 Plaquetes
                        </div>
                        <div id="plasma" class="draggable-item" draggable="true" ondragstart="drag(event)" data-type="liquid" style="background: #f0e68c; color: #333; padding: 15px; border-radius: 10px; cursor: grab;">
                            💧 Plasma
                        </div>
                    </div>

                    <!-- Drop Zones -->
                    <div class="drop-container" style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; width: 100%;">
                        <div class="drop-zone" ondrop="drop(event)" ondragover="allowDrop(event)" data-type="oxygen" style="border: 2px dashed #ff4d4d; padding: 30px; border-radius: 15px; min-height: 150px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
                            <h4 style="pointer-events: none;">Transport d'Oxigen</h4>
                        </div>
                        <div class="drop-zone" ondrop="drop(event)" ondragover="allowDrop(event)" data-type="defense" style="border: 2px dashed #e0e0e0; padding: 30px; border-radius: 15px; min-height: 150px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
                            <h4 style="pointer-events: none;">Defensa Immunitària</h4>
                        </div>
                        <div class="drop-zone" ondrop="drop(event)" ondragover="allowDrop(event)" data-type="clot" style="border: 2px dashed #ffd700; padding: 30px; border-radius: 15px; min-height: 150px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
                            <h4 style="pointer-events: none;">Coagulació</h4>
                        </div>
                        <div class="drop-zone" ondrop="drop(event)" ondragover="allowDrop(event)" data-type="liquid" style="border: 2px dashed #f0e68c; padding: 30px; border-radius: 15px; min-height: 150px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
                            <h4 style="pointer-events: none;">Medi Líquid</h4>
                        </div>
                    </div>
                </div>
                
                <style>
                    .draggable-item:active { cursor: grabbing; }
                    .correct-drop { animation: bounceIn 0.5s; }
                    .shake { animation: shake 0.5s; }
                    .success-pulse { animation: pulseGreen 0.5s; }
                    @keyframes shake { 0%, 100% { transform: translateX(0); } 25% { transform: translateX(-10px); } 75% { transform: translateX(10px); } }
                    @keyframes pulseGreen { 0% { background-color: transparent; } 50% { background-color: rgba(0, 255, 0, 0.2); } 100% { background-color: transparent; } }
                </style>
            </div>
        `
    },

    // Diapositiva 21: Plasma
    {
        content: `
            <div class="slide-bg bg-heart"></div>
            <div class="big-number">55%</div>
            <div class="slide-content">
                <h1 class="slide-title liquid-text">Plasma Sanguini</h1>
                <p class="slide-subtitle">La part líquida de la sang</p>
                <div class="two-columns">
                    <div class="column">
                        <h3>Composició</h3>
                        <p>90% aigua</p>
                        <p style="margin-top: 15px;">7-8% proteïnes (albúmina, anticossos, fibrinogen)</p>
                        <p style="margin-top: 15px;">Nutrients (glucosa, aminoàcids, lípids)</p>
                        <p style="margin-top: 15px;">Minerals (Na⁺, K⁺, Ca²⁺, Cl⁻)</p>
                        <p style="margin-top: 15px;">Hormones i productes de rebuig</p>
                    </div>
                    <div class="column">
                        <h3>Funcions</h3>
                        <p>Transportar nutrients i hormones</p>
                        <p style="margin-top: 15px;">Mantenir la pressió osmòtica</p>
                        <p style="margin-top: 15px;">Regular la temperatura corporal</p>
                        <p style="margin-top: 15px;">Eliminar residus metabòlics</p>
                    </div>
                </div>
            </div>
        `
    },

    // Diapositiva 22: Glòbuls vermells
    {
        content: `
            <div class="slide-bg bg-heart"></div>
            <div class="slide-content">
                <h1 class="slide-title liquid-text">Glòbuls Vermells (Eritròcits)</h1>
                <p class="slide-subtitle">Els transportadors d'oxigen</p>
                <div class="two-columns">
                    <div class="column">
                        <h3>Característiques</h3>
                        <p>Forma de <strong>disc bicòncau</strong></p>
                        <p style="margin-top: 15px;">Sense nucli (més espai per hemoglobina)</p>
                        <p style="margin-top: 15px;">Contenen <strong>hemoglobina</strong> (proteïna amb ferro)</p>
                        <p style="margin-top: 15px;">Vida: ~<strong>120 dies</strong></p>
                        <p style="margin-top: 15px;">Color vermell pel ferro</p>
                    </div>
                    <div class="column">
                        <h3>Dades fascinants</h3>
                        <p>El cos produeix <strong>2,4 milions</strong> de glòbuls vermells <strong>per segon</strong></p>
                        <p style="margin-top: 20px;">Tenim ~<strong>25 bilions</strong> de glòbuls vermells totals</p>
                        <p style="margin-top: 20px;">Cada eritròcit conté <strong>280 milions</strong> de molècules d'hemoglobina</p>
                    </div>
                </div>
            </div>
        `
    },

    // Diapositiva 23: Glòbuls blancs
    {
        content: `
            <div class="slide-bg bg-energy"></div>
            <div class="slide-content">
                <h1 class="slide-title">Glòbuls Blancs (Leucòcits)</h1>
                <p class="slide-subtitle">Els soldats del sistema immunitari</p>
                <ul class="elegant-list">
                    <li><strong>Neutròfils:</strong> Primera línia de defensa contra bacteris</li>
                    <li><strong>Limfòcits:</strong> Produeixen anticossos (immunitat específica)</li>
                    <li><strong>Monòcits:</strong> Fagocitosi potent (s'empassen invasors)</li>
                    <li><strong>Eosinòfils:</strong> Defensa contra paràsits i al·lèrgies</li>
                    <li><strong>Basòfils:</strong> Alliberen histamina en respostes inflamatòries</li>
                </ul>
                <div class="highlight-box" style="margin-top: 30px;">
                    <p>Quan tens una infecció, el cos <strong>augmenta la producció</strong> de glòbuls blancs per combatre-la. Per això en anàlisis de sang es comprova el recompte de leucòcits!</p>
                </div>
            </div>
        `
    },

    // Diapositiva 24: Plaquetes
    {
        content: `
            <div class="slide-bg bg-lymphatic"></div>
            <div class="slide-content">
                <h1 class="slide-title">Plaquetes (Trombòcits)</h1>
                <p class="slide-subtitle">Les reparadores de ferides</p>
                <div class="two-columns">
                    <div class="column">
                        <h3>Què són?</h3>
                        <p>Petits fragments cel·lulars (no són cèl·lules completes)</p>
                        <p style="margin-top: 20px;">Vida: <strong>7-10 dies</strong></p>
                        <p style="margin-top: 20px;">Tenim ~<strong>150.000-400.000</strong> per mm³ de sang</p>
                    </div>
                    <div class="column">
                        <h3>Funció</h3>
                        <p><strong>Coagulació sanguínia:</strong> Quan et talles, les plaquetes s'aglutinen formant un tap</p>
                        <p style="margin-top: 20px;">Alliberen substàncies que activen el fibrinogen</p>
                        <p style="margin-top: 20px;">Formen una xarxa que atura l'hemorràgia</p>
                    </div>
                </div>
            </div>
        `
    },

    // Diapositiva 25: Sistema limfàtic - introducció
    {
        content: `
            <div class="slide-bg bg-lymphatic"></div>
            <div class="slide-content">
                <h1 class="slide-title">Sistema Limfàtic</h1>
                <p class="slide-subtitle">L'altra xarxa de transport</p>
                <div class="highlight-box">
                    <h4>Què és la limfa?</h4>
                    <p style="font-size: 1.3rem;">La limfa és un líquid <strong>transparent o grogós</strong> que es forma quan part del plasma sanguini surt dels capil·lars i s'acumula entre les cèl·lules (líquid intersticial).</p>
                </div>
                <div class="two-columns" style="margin-top: 40px;">
                    <div class="column">
                        <h3>Diferència clau</h3>
                        <p>El sistema limfàtic <strong>NO té cor</strong></p>
                        <p style="margin-top: 15px;">La limfa es mou gràcies a:</p>
                        <p style="margin-top: 10px;">• Contraccions musculars</p>
                        <p style="margin-top: 10px;">• Moviments respiratoris</p>
                        <p style="margin-top: 10px;">• Pulsacions d'artèries properes</p>
                    </div>
                    <div class="column">
                        <h3>Per això...</h3>
                        <p>És tan important fer <strong>exercici físic!</strong></p>
                        <p style="margin-top: 20px;">Quan et mous, ajudes que la limfa circuli millor</p>
                        <p style="margin-top: 20px;">El teu cos elimina toxines i es defensa millor</p>
                    </div>
                </div>
            </div>
        `
    },

    // Diapositiva 26: Components del sistema limfàtic
    {
        content: `
            <div class="slide-bg bg-lymphatic"></div>
            <div class="slide-content">
                <h1 class="slide-title">Components del Sistema Limfàtic</h1>
                <p class="slide-subtitle">La xarxa de defensa i drenatge</p>
                <ul class="elegant-list">
                    <li><strong>Vasos limfàtics:</strong> Conductes cecs (sense sortida) que recullen la limfa dels teixits</li>
                    <li><strong>Ganglis limfàtics:</strong> Estacions de filtratge al coll, aixelles i engonals. Netegen la limfa de microorganismes</li>
                    <li><strong>La melsa:</strong> Filtra la sang, elimina glòbuls vermells vells i emmagatzema sang de reserva</li>
                    <li><strong>El tim:</strong> Òrgan on maduren els limfòcits T (defensa)</li>
                    <li><strong>Amígdales:</strong> Primera barrera defensiva a la gola</li>
                </ul>
            </div>
        `
    },

    // Diapositiva 27: Funcions del sistema limfàtic
    {
        content: `
            <div class="slide-bg bg-lymphatic"></div>
            <div class="slide-content">
                <h1 class="slide-title">Funcions del Sistema Limfàtic</h1>
                <p class="slide-subtitle">Tres funcions vitals</p>
                <div class="data-grid" style="grid-template-columns: 1fr 1fr 1fr;">
                    <div class="data-item">
                        <h5>1. Retornar líquid</h5>
                        <p style="margin-top: 15px;">Recull el plasma que ha sortit dels capil·lars sanguinis</p>
                        <p style="margin-top: 10px;">El retorna a la circulació sanguínia</p>
                        <p style="margin-top: 10px;">Evita l'edema (acumulació de líquid)</p>
                    </div>
                    <div class="data-item">
                        <h5>2. Transportar greixos</h5>
                        <p style="margin-top: 15px;">Els greixos absorbits a l'intestí són massa grans</p>
                        <p style="margin-top: 10px;">No poden passar directament als capil·lars sanguinis</p>
                        <p style="margin-top: 10px;">Viatgen primer per la limfa</p>
                    </div>
                    <div class="data-item">
                        <h5>3. Defensa immunitària</h5>
                        <p style="margin-top: 15px;">Als ganglis limfàtics es generen limfòcits</p>
                        <p style="margin-top: 10px;">Produeixen anticossos</p>
                        <p style="margin-top: 10px;">Combaten infeccions</p>
                    </div>
                </div>
            </div>
        `
    },

    // Diapositiva 28: Ganglis limfàtics i infeccions
    {
        content: `
            <div class="slide-bg bg-lymphatic"></div>
            <div class="slide-content">
                <h1 class="slide-title">Ganglis Limfàtics</h1>
                <p class="slide-subtitle">Les estacions de filtratge</p>
                <div class="highlight-box">
                    <h4>Curiositat important!</h4>
                    <p style="font-size: 1.3rem;">Quan tens una infecció (per exemple, un mal de coll), els ganglis limfàtics del coll <strong>s'inflamen i es fan palpables</strong>.</p>
                </div>
                <div class="two-columns" style="margin-top: 40px;">
                    <div class="column">
                        <h3>Per què s'inflamen?</h3>
                        <p>Estan treballant <strong>intensament</strong> filtrant microorganismes</p>
                        <p style="margin-top: 20px;">Produeixen més <strong>cèl·lules de defensa</strong></p>
                        <p style="margin-top: 20px;">Poden augmentar de mida fins a <strong>10 vegades</strong></p>
                    </div>
                    <div class="column">
                        <h3>Ubicacions principals</h3>
                        <p>Coll</p>
                        <p style="margin-top: 15px;">Aixelles</p>
                        <p style="margin-top: 15px;">Engonals</p>
                        <p style="margin-top: 15px;">Abdomen</p>
                        <p style="margin-top: 15px;">Tòrax</p>
                    </div>
                </div>
            </div>
        `
    },

    // Diapositiva 29: Comparació circulatori vs limfàtic
    {
        content: `
            <div class="slide-bg bg-lymphatic"></div>
            <div class="slide-content">
                <h1 class="slide-title">Circulatori vs Limfàtic</h1>
                <p class="slide-subtitle">Comparació dels dos sistemes</p>
                <div style="overflow-x: auto; max-width: 100%;">
                    <table style="width: 100%; border-collapse: collapse; margin-top: 30px; font-size: 1.1rem;">
                        <tr style="background: rgba(220, 20, 60, 0.3);">
                            <th style="padding: 15px; border: 2px solid #fff; text-align: left;">Característica</th>
                            <th style="padding: 15px; border: 2px solid #fff;">Sistema Circulatori</th>
                            <th style="padding: 15px; border: 2px solid #fff;">Sistema Limfàtic</th>
                        </tr>
                        <tr>
                            <td style="padding: 12px; border: 1px solid #fff;"><strong>Líquid principal</strong></td>
                            <td style="padding: 12px; border: 1px solid #fff;">Sang</td>
                            <td style="padding: 12px; border: 1px solid #fff;">Limfa</td>
                        </tr>
                        <tr>
                            <td style="padding: 12px; border: 1px solid #fff;"><strong>Color del líquid</strong></td>
                            <td style="padding: 12px; border: 1px solid #fff;">Vermell</td>
                            <td style="padding: 12px; border: 1px solid #fff;">Transparent/grogós</td>
                        </tr>
                        <tr>
                            <td style="padding: 12px; border: 1px solid #fff;"><strong>Bomba</strong></td>
                            <td style="padding: 12px; border: 1px solid #fff;">Cor</td>
                            <td style="padding: 12px; border: 1px solid #fff;">No en té</td>
                        </tr>
                        <tr>
                            <td style="padding: 12px; border: 1px solid #fff;"><strong>Tipus de circuit</strong></td>
                            <td style="padding: 12px; border: 1px solid #fff;">Tancat (circular)</td>
                            <td style="padding: 12px; border: 1px solid #fff;">Obert (un sol sentit)</td>
                        </tr>
                        <tr>
                            <td style="padding: 12px; border: 1px solid #fff;"><strong>Velocitat</strong></td>
                            <td style="padding: 12px; border: 1px solid #fff;">Ràpida (&lt;1 min)</td>
                            <td style="padding: 12px; border: 1px solid #fff;">Lenta (hores/dies)</td>
                        </tr>
                        <tr>
                            <td style="padding: 12px; border: 1px solid #fff;"><strong>Funció principal</strong></td>
                            <td style="padding: 12px; border: 1px solid #fff;">Transport O₂ i nutrients</td>
                            <td style="padding: 12px; border: 1px solid #fff;">Recollir líquids i defensa</td>
                        </tr>
                    </table>
                </div>
            </div>
        `
    },

    // Diapositiva 30: Transport de nutrients específics
    {
        content: `
            <div class="slide-bg bg-energy"></div>
            <div class="slide-content">
                <h1 class="slide-title">Transport de Nutrients Específics</h1>
                <p class="slide-subtitle">Com viatgen les diferents substàncies</p>
                <div class="data-grid">
                    <div class="data-item">
                        <h5>Aigua</h5>
                        <p>Representa el <strong>60% del pes corporal</strong></p>
                        <p style="margin-top: 10px;">Viatja per sang i limfa</p>
                    </div>
                    <div class="data-item">
                        <h5>Oxigen (O₂)</h5>
                        <p>Unit a l'<strong>hemoglobina</strong> dels glòbuls vermells</p>
                        <p style="margin-top: 10px;">Dels pulmons a les cèl·lules</p>
                    </div>
                    <div class="data-item">
                        <h5>CO₂</h5>
                        <p>De les cèl·lules als pulmons</p>
                        <p style="margin-top: 10px;">Per ser <strong>exhalat</strong></p>
                    </div>
                    <div class="data-item">
                        <h5>Glucosa</h5>
                        <p>Absorbida a l'intestí</p>
                        <p style="margin-top: 10px;">Viatja per la sang com a <strong>font d'energia</strong></p>
                    </div>
                    <div class="data-item">
                        <h5>Aminoàcids</h5>
                        <p>De l'intestí a les cèl·lules</p>
                        <p style="margin-top: 10px;">Per <strong>construir proteïnes</strong></p>
                    </div>
                    <div class="data-item">
                        <h5>Greixos</h5>
                        <p>Absorbits com a <strong>quilomicrons</strong></p>
                        <p style="margin-top: 10px;">Primer per limfa, després per sang</p>
                    </div>
                </div>
            </div>
        `
    },

    // Diapositiva 31: Metabolisme cel·lular
    {
        content: `
            <div class="slide-bg bg-energy"></div>
            <div class="big-number">ATP</div>
            <div class="slide-content">
                <h1 class="slide-title">Metabolisme Cel·lular</h1>
                <p class="slide-subtitle">Què fan les cèl·lules amb els nutrients?</p>
                <div class="two-columns">
                    <div class="column">
                        <h3 style="color: #4CAF50;">Anabolisme</h3>
                        <p>Les cèl·lules <strong>construeixen</strong> noves molècules:</p>
                        <p style="margin-top: 15px;">• Proteïnes</p>
                        <p style="margin-top: 10px;">• ADN i ARN</p>
                        <p style="margin-top: 10px;">• Membranes cel·lulars</p>
                        <p style="margin-top: 10px;">• Components estructurals</p>
                    </div>
                    <div class="column">
                        <h3 style="color: #FF6B6B;">Catabolisme</h3>
                        <p>Les cèl·lules <strong>descomponen</strong> molècules:</p>
                        <p style="margin-top: 15px;">• Glucosa → Energia (ATP)</p>
                        <p style="margin-top: 10px;">• Greixos → Energia</p>
                        <p style="margin-top: 10px;">• Genera <strong>residus</strong>: CO₂, urea</p>
                    </div>
                </div>
                <div class="highlight-box" style="margin-top: 30px;">
                    <p>Els residus (CO₂ i urea) són recollits per la sang i transportats als pulmons i ronyons per ser eliminats.</p>
                </div>
            </div>
        `
    },

    // Diapositiva 32: Cuidar el sistema circulatori i limfàtic
    {
        content: `
            <div class="slide-bg bg-energy"></div>
            <div class="slide-content">
                <h1 class="slide-title">Cuida els teus Sistemes de Transport</h1>
                <p class="slide-subtitle">Consells pràctics per a la salut</p>
                <div class="two-columns image-text">
                    <div class="column">
                        <img src="imagen-cuerpo-masculino.jpg" alt="Cos humà saludable" class="slide-image" style="max-height: 500px;">
                    </div>
                    <div class="column">
                        <h3 style="color: #4CAF50;">Alimentació equilibrada</h3>
                        <p>Fruites, verdures, proteïnes, cereals integrals</p>
                        <p style="margin-top: 10px;">Beure 1,5-2 litres d'aigua al dia</p>
                        <p style="margin-top: 10px;">Evitar excés de sal i greixos saturats</p>
                        
                        <h3 style="margin-top: 25px; color: #FF9800;">Exercici físic regular</h3>
                        <p>Caminar, córrer, nedar, ioga...</p>
                        <p style="margin-top: 10px;">Ajuda que sang i limfa circulin millor</p>
                        <p style="margin-top: 10px;">Enforteix el cor i oxigena el cos</p>
                        
                        <h3 style="margin-top: 25px; color: #2196F3;">Descans adequat</h3>
                        <p>Dormir 8-9 hores</p>
                        <p style="margin-top: 10px;">Durant el son el sistema limfàtic neteja el cervell</p>
                    </div>
                </div>
            </div>
        `
    },

    // Diapositiva 33: Evitar hàbits nocius
    {
        content: `
            <div class="slide-bg bg-energy"></div>
            <div class="slide-content">
                <h1 class="slide-title">Evita Hàbits Nocius</h1>
                <p class="slide-subtitle">Protegeix el teu sistema circulatori</p>
                <div class="data-grid" style="grid-template-columns: 1fr 1fr;">
                    <div class="data-item">
                        <h5>No fumar</h5>
                        <p style="margin-top: 15px;">El tabac <strong>danya els vasos sanguinis</strong></p>
                        <p style="margin-top: 10px;">Dificulta el transport d'oxigen</p>
                        <p style="margin-top: 10px;">Augmenta el risc de malalties cardiovasculars</p>
                    </div>
                    <div class="data-item">
                        <h5>No abusar de l'alcohol</h5>
                        <p style="margin-top: 15px;">Afecta el <strong>fetge</strong></p>
                        <p style="margin-top: 10px;">Altera la producció de cèl·lules sanguínies</p>
                        <p style="margin-top: 10px;">Danya la melsa i els ronyons</p>
                    </div>
                </div>
                <div class="highlight-box" style="margin-top: 40px;">
                    <h4>Evita també:</h4>
                    <p style="font-size: 1.2rem;">El <strong>sedentarisme</strong> (debilita el cor) • L'<strong>estrès crònic</strong> (augmenta la pressió arterial) • L'<strong>excés de sal</strong> (hipertensió)</p>
                </div>
            </div>
        `
    },

    // Diapositiva 34: Curiositats i dades fascinants
    {
        content: `
            <div class="slide-bg bg-energy"></div>
            <div class="slide-content">
                <h1 class="slide-title">Curiositats Fascinants</h1>
                <p class="slide-subtitle">El cos humà en xifres extraordinàries</p>
                <div class="data-grid">
                    <div class="data-item">
                        <h5>3.000 milions</h5>
                        <p>Batecs del cor en 80 anys de vida</p>
                    </div>
                    <div class="data-item">
                        <h5>&lt;1 minut</h5>
                        <p>Temps per fer un circuit complet de sang en repòs</p>
                    </div>
                    <div class="data-item">
                        <h5>20 segons</h5>
                        <p>Circuit complet quan fas exercici intens!</p>
                    </div>
                    <div class="data-item">
                        <h5>120 dies</h5>
                        <p>Vida d'un glòbul vermell abans de ser eliminat</p>
                    </div>
                    <div class="data-item">
                        <h5>2,4 milions/seg</h5>
                        <p>Glòbuls vermells produïts cada segon</p>
                    </div>
                    <div class="data-item">
                        <h5>250 ml</h5>
                        <p>Sang de reserva emmagatzemada a la melsa</p>
                    </div>
                </div>
            </div>
        `
    },

    // Diapositiva 35: Més curiositats
    {
        content: `
            <div class="slide-bg bg-energy"></div>
            <div class="slide-content">
                <h1 class="slide-title">Més Dades Increïbles</h1>
                <p class="slide-subtitle">Sabies que...?</p>
                <ul class="elegant-list">
                    <li>Els ganglis limfàtics poden <strong>augmentar de mida fins a 10 vegades</strong> quan lluiten contra una infecció greu</li>
                    <li>Si posessin tots els vasos sanguinis en línia, farien <strong>97.000 quilòmetres</strong> (2,5 voltes al món!)</li>
                    <li>Els capil·lars tenen una superfície total de <strong>600 m²</strong> (gairebé la mida de dues pistes de tennis!)</li>
                    <li>El cor bombeja aproximadament <strong>7.000 litres de sang cada dia</strong> (una petita piscina setmanalment)</li>
                    <li>La melsa pot filtrar fins a <strong>350 ml de sang per minut</strong></li>
                </ul>
            </div>
        `
    },

    // Diapositiva 36: Conclusió final
    {
        content: `
            <div class="slide-bg bg-energy"></div>
            <div class="slide-content">
                <h1 class="slide-title">Conclusió</h1>
                <p class="slide-subtitle">Un sistema perfectament coordinat</p>
                <div class="highlight-box">
                    <h4>El transport de substàncies en el cos humà</h4>
                    <p style="font-size: 1.3rem;">És un procés <strong>complex i meravellosament coordinat</strong> que ocorre simultàniament a tres nivells:</p>
                </div>
                <div class="data-grid" style="margin-top: 40px;">
                    <div class="data-item">
                        <h5>1. A nivell cel·lular</h5>
                        <p>La membrana plasmàtica regula què entra i surt mitjançant transport passiu i actiu</p>
                    </div>
                    <div class="data-item">
                        <h5>2. A nivell corporal</h5>
                        <p>El sistema circulatori distribueix ràpidament oxigen i nutrients a tot el cos</p>
                    </div>
                    <div class="data-item">
                        <h5>3. Com a complement</h5>
                        <p>El sistema limfàtic recull líquids, transporta greixos i defensa l'organisme</p>
                    </div>
                </div>
                <p style="margin-top: 40px; font-size: 1.2rem; text-align: center; color: #FFD700;"><strong>Tots aquests sistemes treballen junts les 24 hores del dia, 7 dies a la setmana!</strong></p>
            </div>
        `
    },

    // Diapositiva 37: Recordatori final
    {
        content: `
            <div class="slide-bg bg-energy"></div>
            <div class="slide-content">
                <h1 class="slide-title">Recordatori Final</h1>
                <p class="slide-subtitle">Cuida el teu cos!</p>
                <div class="two-columns image-text">
                    <div class="column">
                        <img src="imagen-corazon-detall.jpg" alt="Cor humà" class="slide-image" style="max-height: 500px;">
                    </div>
                    <div class="column">
                        <p style="font-size: 1.5rem; line-height: 1.8;">Cuidar la teva <strong>alimentació</strong>, fer <strong>exercici regularment</strong> i <strong>descansar bé</strong> són les millors maneres d'ajudar aquests sistemes a mantenir-te sa i ple d'energia!</p>
                        <p style="margin-top: 30px; font-size: 1.4rem; line-height: 1.8; color: #FFD700;">El teu cos és una màquina increïble: <strong>tracta-la amb respecte</strong> i t'acompanyarà durant tota la vida.</p>
                        <p style="margin-top: 40px; font-size: 1.3rem; text-align: center; color: #FF6B6B;">Cada una dels <strong>bilions de cèl·lules</strong> del teu cos rep el que necessita gràcies a aquests sistemes!</p>
                    </div>
                </div>
            </div>
        `
    },

    // Diapositiva 38: Gràcies
    {
        content: `
            <div class="slide-bg bg-energy"></div>
            <div class="slide-content">
                <h1 class="slide-title">Gràcies per la vostra atenció!</h1>
                <p class="slide-subtitle">El Transport de Substàncies al Cos Humà</p>
                <div class="highlight-box" style="max-width: 700px;">
                    <p style="font-size: 1.5rem; color: #ffffff; text-align: center;">Hem explorat els mecanismes fascinants del transport cel·lular, el sistema circulatori i el sistema limfàtic</p>
                </div>
                <div style="margin-top: 50px; font-size: 1.4rem; color: #d0d0d0; text-align: center;">
                    <p>Presentat per:</p>
                    <p style="margin-top: 20px;"><strong>Aissa Rousi • Ivan Rios • Roger Omegna</strong></p>
                    <p style="margin-top: 10px;"><strong>Unai Jimenez • Yeremi Suarez</strong></p>
                    <p style="margin-top: 30px; font-size: 1.2rem; color: #999;">3r ESO</p>
                </div>
                <div style="margin-top: 40px; text-align: center;">
                    <button onclick="startMultiplayerQuiz()" style="padding: 20px 50px; font-size: 1.5rem; font-weight: bold; background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%); color: #333; border: none; border-radius: 15px; cursor: pointer; box-shadow: 0 10px 30px rgba(255, 215, 0, 0.5); transition: all 0.3s; animation: pulseGlow 2s ease infinite;" onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'">Iniciar Quiz Multiplayer</button>
                </div>
                <p style="margin-top: 30px; font-size: 1.1rem; color: #FFD700; animation: clickPulse 1.5s ease infinite;">Clic per tornar al principi</p>
            </div>
        `
    }
];
